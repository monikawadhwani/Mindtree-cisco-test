-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 26, 2020 at 12:08 PM
-- Server version: 8.0.12
-- PHP Version: 7.1.33-17+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mindDb`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2020-06-11-045825', 'App\\Database\\Migrations\\RouterDetail', 'default', 'App', 1592036426, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `router`
-- (See below for the actual view)
--
CREATE TABLE `router` (
`sapid` varchar(225)
,`hostname` varchar(225)
,`loopback` varchar(255)
,`macadd` varchar(255)
,`status` int(10) unsigned
);

-- --------------------------------------------------------

--
-- Table structure for table `routerDetail`
--

CREATE TABLE `routerDetail` (
  `id` int(10) UNSIGNED NOT NULL,
  `sapid` varchar(225) NOT NULL,
  `hostname` varchar(225) NOT NULL,
  `loopback` varchar(255) NOT NULL,
  `macadd` varchar(255) NOT NULL,
  `status` int(10) UNSIGNED NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `routerDetail`
--

INSERT INTO `routerDetail` (`id`, `sapid`, `hostname`, `loopback`, `macadd`, `status`, `created_date`, `modified_date`) VALUES
(9, '54:45:56:67:78:89/1', 'https://www.abcd.com', '145.23.562.852', '05:cd:78:a0:b4:c6', 0, '2020-09-10 10:02:02', '2020-09-26 04:32:02');

-- --------------------------------------------------------

--
-- Structure for view `router`
--
DROP TABLE IF EXISTS `router`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `router`  AS  select `routerDetail`.`sapid` AS `sapid`,`routerDetail`.`hostname` AS `hostname`,`routerDetail`.`loopback` AS `loopback`,`routerDetail`.`macadd` AS `macadd`,`routerDetail`.`status` AS `status` from `routerDetail` where (`routerDetail`.`status` = 1) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `routerDetail`
--
ALTER TABLE `routerDetail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `routerDetail`
--
ALTER TABLE `routerDetail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
