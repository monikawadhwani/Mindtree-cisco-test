 <?php
 $username;
        $this->ftpPass = $password;
        $this->ftpHost = $hostname;

        $this->initConn();
    }

    // --------------------------------------------------------------------

    /**
     * Init connection method - connect to ftp server and set passive mode
     *
     * @return  bool
     */
    function initConn()
    {
        $this->conn = ftp_connect($this->ftpHost);
        $this->login_result = ftp_login($this->conn, $this->ftpUser, $this->ftpPass);
        if($this->conn && $this->login_result)
        {
            ftp_pasv($this->conn, $this->ftpPasv);
            return true;
        }       
        return false;
    }

    // --------------------------------------------------------------------

    /**
     * Put method - upload files(folders) to ftp server
     *
     * @param   string  path to destionation file/folder on ftp
     * @param   string  path to source file/folder on local disk
     * @param   int only for identify reattempt, dont use this param
     * @return  bool
     */
    public function put($destinationFile, $sourceFile, $retry = 0)
    {   
        if(file_exists($sourceFile))
        { 
            if(!$this->isDir($sourceFile, true))
            {
                $this->createSubDirs($destinationFile);
                if(!ftp_put($this->conn, $destinationFile, $sourceFile, $this->ftpMode))
                {
                    $retry++;
                    if($retry > $this->retry)
                    {
                        $this->logData('Error when uploading file: '.$sourceFile.' => '.$destinationFile, 'error');
                        return false;
                    }
                    if($this->verbose) echo 'Retry: '.$retry."\n";
                    $this->reconnect();
                    $this->put($destinationFile, $sourceFile, $retry);
                }
                else
                {
                    $this->logData('Upload:'.$sourceFile.' => '.$destinationFile, 'ok');
                    return true;
                }
            }
            else
            {
                $this->recursive($destinationFile, $sourceFile, 'put');
            }
        }       
    }

    

    /**
     * Reconnect method
     *
     * @return  void
     */
    public function reconnect()
    {
        $this->closeConn();
        $this->initConn();
    }

    // --------------------------------------------------------------------

    /**
     * Close connection method
     *
     * @return  void
     */
    public function closeConn()
    {
        return ftp_close($this->conn);
    }


// END ftp class

/* End of file ftp.php */
/* Location: ftp.php */
?>