<?php
/********My SQL Query********/

$conn = new mysqli("localhost", "root", "root", "mindDb");


$sql = "SELECT sapid,hostname,loopback,macadd, status FROM routerDetail WHERE status=1";


/*****Create View (Run in Mysql)*****/
CREATE VIEW router1 AS 
SELECT sapid,hostname,loopback,macadd, status FROM routerDetail 
WHERE status=1



******Insert 10 more values in table*****

$randIP = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);

$i=1;
while($i<=10){

$sapid = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);

$loopback = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);

$macaddress = implode(':', str_split(str_pad(base_convert(mt_rand(0, 0xffffff), 10, 16) . base_convert(mt_rand(0, 0xffffff), 10, 16), 12), 2));

$hostname = "cisco_".rand(3).".com";

mysqli_query("INSERT INTO routerDetail(sapid,hostname,loopback,macadd,status) values('".$sapid."','".$hostname."','".$loopback."','".$macaddress."',1)");
}



?>