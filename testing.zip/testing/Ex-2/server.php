<?php
/***********Connection to SSH**********/
$conn = ssh2_connect('example.com', 22);
ssh2_auth_password($conn, 'username', 'password');


// /************DISK USAGE CHECK****************/

/* get disk space free (in bytes) */
$df = disk_free_space("/var/www");
/* and get disk space total (in bytes)  */
$dt = disk_total_space("/var/www");
/* now we calculate the disk space used (in bytes) */
$du = $dt - $df;
 percentage of disk used - this will be used to also set the width % of the progress bar 
echo $dp = sprintf('%.2f',($du / $dt) * 100);

 and we formate the size from bytes to MB, GB, etc. 
$df = formatSize($df);
$du = formatSize($du);
$dt = formatSize($dt);

function formatSize( $bytes )
{
        $types = array( 'B', 'KB', 'MB', 'GB', 'TB' );
        for( $i = 0; $bytes >= 1024 && $i < ( count( $types ) -1 ); $bytes /= 1024, $i++ );
                return( round( $bytes, 2 ) . " " . $types[$i] );
}

// /*******************Inode Usage***************************/
$filename = 'filename';
if (getmyinode() == fileinode($filename)) {
    echo 'You are checking the current file.';
}


/*******************Get List of all files***********************************/
$dir = "/var/www/html/testing";


function dirToArray($dir) {
  
   $result = array();

   $cdir = scandir($dir);
   foreach ($cdir as $key => $value)
   {
      if (!in_array($value,array(".","..")))
      {
         if (is_dir($dir . "/" . $value))
         {
            $result[$value] = dirToArray($dir . "/" . $value);
         }
         else
         {
            $result[] = $value;
         }
      }
   }
  
   return $result;
}

$result = dirToArray($dir);
print_r($result);

/***********************Copy files from FTP**********************************/


set_time_limit(0);
require 'ftp.php';


$ftp = new ftp();
$ftp->conn('host', 'username', 'password');
$ftp->get('download/demo', '/demo'); // download live "/demo" folder to local "download/demo"

$ftp->put('/demo/test', 'upload/vjtest'); // upload local "upload/vjtest" to live "/demo/test"

$arr = $ftp->getLogData();
if ($arr['error'] != "")
    echo '<h2>Error:</h2>' . implode('<br />', $arr['error']);
if ($arr['ok'] != "")
    echo '<h2>Success:</h2>' . implode('<br />', $arr['ok']);


/*************************Restart Apache server*****************************/

exec('/sbin/service apache2 restart');

?>