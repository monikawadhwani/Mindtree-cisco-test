<?php
// Status flag:
$LoginSuccessful = false;
 
// Check username and password:
if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])){
 
    $Username = $_SERVER['PHP_AUTH_USER'];
    $Password = $_SERVER['PHP_AUTH_PW'];
 
    if ($Username == 'Monika' && $Password == 'Wadhwani'){
        $LoginSuccessful = true;
    }
}
 
// Login passed successful?
if (!$LoginSuccessful){
 

    header('WWW-Authenticate: Basic realm="Access denied"');
    header('HTTP/1.0 401 Unauthorized');
 
    print "Login failed!\n";
 
}
else {
 
    print 'You are login successfully';
}
?>