<?php
// used to get mysql database connection
class DatabaseService{

    private $db_host = "localhost";
    private $db_name = "mindDb";
    private $db_user = "root";
    private $db_password = "root";
    private $connection;

    public function getConnection(){

        $this->connection = null;

        try{
            $this->connection = new PDO("mysql:host=" . $this->db_host . ";dbname=" . $this->db_name, $this->db_user, $this->db_password);            
        }catch(PDOException $exception){
            echo "Connection failed: " . $exception->getMessage();
        }        
        return $this->connection;
    }

    public function install($con){
        $sql = "CREATE  TABLE IF NOT EXISTS `routerDetails` (
              `id` INT  AUTO_INCREMENT ,
              `sapid` VARCHAR(225) NOT NULL ,
              `hostname` VARCHAR(225) NOT NULL ,
              `loopback` VARCHAR(255) NOT NULL,
              `macadd` VARCHAR(255) NOT NULL,
              `status` INT,
              PRIMARY KEY (`id`) )";

            // prepare query statement
        $stmt = $con->prepare($sql);
      
        // execute query
        $stmt->execute();
      
        return $stmt;
    }
}
?>