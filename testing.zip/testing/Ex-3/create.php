<?php
// ini_set('display_errors', 1); 
// ini_set('display_startup_errors', 1); 
// error_reporting(E_ALL); 
if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])){
 
    $Username = $_SERVER['PHP_AUTH_USER'];
    $Password = $_SERVER['PHP_AUTH_PW'];
 
    if ($Username == 'Monika' && $Password == 'Wadhwani'){
        $LoginSuccessful = true;
    }else{
        header('WWW-Authenticate: Basic realm="Access denied"');
        header('HTTP/1.0 401 Unauthorized');
    }
}
if($LoginSuccessful){
    // get database connection
    include_once 'config/database.php';
    include_once 'router.php';
      
    $database = new DatabaseService();
    $db = $database->getConnection();

      
    $router = new Router($db);
  
    // get posted data
    $data = json_decode(file_get_contents("php://input"));
    //print_r($data);
    // $json_val = '{
    //     "sapid": "54:45:56:67:78", 
    //     "hostname":"https://www.abcd.com",
    //     "loopback":"145.23.563.852", 
    //      "macadd": "05:cd:78:a0:b4:c6"
    //      }
    //      ';
    // $data = json_decode($json_val);
    // make sure data is not empty
    if(
        !empty($data->sapid) &&
        !empty($data->hostname) &&
        !empty($data->loopback) &&
        !empty($data->macadd)
    ){
    
        // set router property values
        $router->sapid = $data->sapid;
        $router->hostname = $data->hostname;
        $router->loopback = $data->loopback;
        $router->macadd = $data->macadd;   
        $router->status = 1; 
        $router->created_date = date('Y-m-h H:i:s');
    
        //check if already exist
        $router_exist = $router->checkexist($router->loopback,$router->hostname);
        if($router_exist){
            // set response code - 400 bad request
            http_response_code(400);
        
            // tell the router
            echo json_encode(array("message" => "Loopback OR hostname value already exist"));

        }else{

            // create router
            if($router->createRouter()){
        
                // set response code - 201 created
                http_response_code(201);
        
                // tell the router
                echo json_encode(array("message" => "router was created."));
            }
        
            // if unable to create the router, tell the router
            else{
        
                // set response code - 503 service unavailable
                http_response_code(503);
        
                // tell the router
                echo json_encode(array("message" => "Unable to create router."));
            }
        }
    }
    
    // tell the router data is incomplete
    else{
    
        // set response code - 400 bad request
        http_response_code(400);
    
        // tell the router
        echo json_encode(array("message" => "Unable to create router. Data is incomplete."));
    }
 }



 
?>