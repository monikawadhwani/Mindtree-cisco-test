<?php
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL); 

include_once 'config/database.php';
include_once 'router.php';

// required headers
if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])){
 
    $Username = $_SERVER['PHP_AUTH_USER'];
    $Password = $_SERVER['PHP_AUTH_PW'];
 
    if ($Username == 'Monika' && $Password == 'Wadhwani'){
        $LoginSuccessful = true;
    }else{
        header('WWW-Authenticate: Basic realm="Access denied"');
        header('HTTP/1.0 401 Unauthorized');
    }
}
if($LoginSuccessful){

        // instantiate database and router object
        $database = new DatabaseService();
        $db = $database->getConnection();


        /**Get api for router**/
        $router = new Router($db);	

        // get id of router to be edited
        $data = json_decode(file_get_contents("php://input"));	
        // $json_val = '{     
        //     "sapid": "54:45:56:67:78", 
        //     "hostname":"https://www.monika.com",
        //     "loopback":"256.23.563.853", 
        //     "macadd": "05:cd:78:a0:b4:c6"
        //     }
        //     ';
        // $data = json_decode($json_val);
        //print_r($data); die;
        if(           
            !empty($data->sapid) &&
            !empty($data->hostname) &&
            !empty($data->loopback) &&
            !empty($data->macadd)
        ){

                
                // set router property values
                $router->sapid = $data->sapid;
                $router->hostname = $data->hostname;
                $router->loopback = $data->loopback;
                $router->macadd = $data->macadd;   
                
                //check if IP already exist
                $router_exist = $router->checkexistLoop($router->loopback);

                if($router_exist){
                   
                    // update the router
                    if($router->updateRouter()){
                    
                        // set response code - 200 ok
                        http_response_code(200);
                    
                        // tell the router
                        echo json_encode(array("message" => "router was updated."));
                    }
                    
                    // if unable to update the router, tell the router
                    else{
                    
                        // set response code - 503 service unavailable
                        http_response_code(503);
                    
                        // tell the router
                        echo json_encode(array("message" => "Unable to update router."));
                    }
                }else{
                    // set response code - 400 bad request
                    http_response_code(400);
                
                    // tell the router
                    echo json_encode(array("message" => "IP does not exist"));
                }
            }
        // tell the router data is incomplete
        else{
        
            // set response code - 400 bad request
            http_response_code(400);
        
            // tell the router
            echo json_encode(array("message" => "Unable to update router. Data is incomplete."));
        }

}
?>
