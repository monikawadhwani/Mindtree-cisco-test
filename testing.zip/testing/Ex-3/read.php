<?php
// ini_set('display_errors', 1); 
// ini_set('display_startup_errors', 1); 
// error_reporting(E_ALL); 

include_once 'config/database.php';
include_once 'router.php';

if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])){
 
    $Username = $_SERVER['PHP_AUTH_USER'];
    $Password = $_SERVER['PHP_AUTH_PW'];
 
    if ($Username == 'Monika' && $Password == 'Wadhwani'){
        $LoginSuccessful = true;
    }else{
        header('WWW-Authenticate: Basic realm="Access denied"');
        header('HTTP/1.0 401 Unauthorized');
    }
}
if($LoginSuccessful){

        // instantiate database and router object
        $database = new DatabaseService();
        $db = $database->getConnection();


        /**Get api for router**/
        $router = new Router($db);	

        // get id of router to be edited
        $data = json_decode(file_get_contents("php://input"));	
        // $json_val = '{
        //     "ip" : "152.523.569.856"
        //     }
        //     ';
        // $data = json_decode($json_val);
        //print_r($data); die;
                              
        // read all the router
        $routerDetails = $router->fetchAllRouter();
        if(!empty($routerDetails)){            
            // set response code - 200 ok
            http_response_code(200);
        
            // tell the router
            echo json_encode(array("message" => "Success", "result" => $routerDetails));
        }
        
        // if unable to update the router, tell the router
        else{
        
            // set response code - 503 service unavailable
            http_response_code(503);
        
            // tell the router
            echo json_encode(array("message" => "No data found."));
        }
                
       
       

}
?>


