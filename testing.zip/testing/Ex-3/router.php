<?php
include_once 'config/database.php';

class Router{
  
    // database connection and table name
    private $conn;
    private $table_name = "routerDetail";
  
    // object properties
    public $id;
    public $sapid;
    public $hostname;
    public $loopback;
	public $macadd;
	public $status;
	public $created_date;
  
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // Get api
	public function getRouterDetail($id){
	  
	    // select all query
	    $query = "SELECT * FROM " . $this->table_name . " WHERE id =".$id;
	  
	    // prepare query statement
	    $stmt = $this->conn->prepare($query);
	  
	    // execute query
	    $stmt->execute();
	  
	    return $stmt;
	}


	//post api

	public function createRouter(){
		//echo $this->sapid."', '".$this->hostname."', '".$this->loopback."', '".$this->macadd;die;
		// query to insert record
	    $query = "INSERT INTO routerDetail (sapid, hostname, loopback, macadd,status,created_date) 
		
				VALUES(:sapid,:hostname,:loopback,:macadd,:status,:created_date)";
		
	    // prepare query
	    $stmt = $this->conn->prepare($query);	    
	  
	    // bind values
	    $stmt->bindParam(":sapid", $this->sapid);
	    $stmt->bindParam(":hostname", $this->hostname);
	    $stmt->bindParam(":loopback", $this->loopback);
	    $stmt->bindParam(":macadd", $this->macadd);	  
		$stmt->bindParam(":status", $this->status);	    
		$stmt->bindParam(":created_date", $this->created_date);	 
	  
	    // execute query
	    if($stmt->execute()){
	        return true;
	    }
	  
	    return false;

	}

	// put api

	public function updateRouter(){
		// update query
	    $query = "UPDATE
	                " . $this->table_name . "
	            SET
	                sapid=:sapid, hostname=:hostname, macadd=:macadd
	            WHERE
				loopback=:loopback";
	  
	    // prepare query statement
	    $stmt = $this->conn->prepare($query);
	  
	    // bind new values
	    $stmt->bindParam(":sapid", $this->sapid);
	    $stmt->bindParam(":hostname", $this->hostname);
	    $stmt->bindParam(":loopback", $this->loopback);
	    $stmt->bindParam(":macadd", $this->macadd);	  
	    // $stmt->bindParam(":id", $this->id);	    
	  
	    // execute the query
	    if($stmt->execute()){
	        return true;
	    }
	  
	    return false;

	}

	public function deleteRouter(){
			// delete query
	    $query = "DELETE FROM " . $this->table_name . " WHERE loopback = ?";
	  
	    // prepare query
	    $stmt = $this->conn->prepare($query);
	  
	    // sanitize
	    $this->id=htmlspecialchars(strip_tags($this->loopback));
	  
	    // bind id of record to delete
	    $stmt->bindParam(1, $this->loopback);
	  
	    // execute query
	    if($stmt->execute()){
	        return true;
	    }
	  
	    return false;
	}

	public function checkexist(){
		$query = "SELECT id FROM routerDetail WHERE loopback='".$this->loopback."' OR hostname='".$this->hostname."'";
		// prepare query
		$stmt = $this->conn->query($query);
		$routerDetail = $stmt->fetch();
		if(!empty($routerDetail)){
			return true;
		}else{
			return false;
		}
	}

	public function checkexistLoop(){
		$query = "SELECT id FROM routerDetail WHERE loopback='".$this->loopback."'";
		// prepare query
		$stmt = $this->conn->query($query);
		$routerDetail = $stmt->fetch();
		if(!empty($routerDetail)){
			return true;
		}else{
			return false;
		}
	}

	public function fetchAllRouter(){
		$query = "SELECT * FROM routerDetail";
		// prepare query
		$stmt = $this->conn->query($query);
		$routerDetail = $stmt->fetchAll(PDO::FETCH_ASSOC);
		if(!empty($routerDetail)){
			return json_encode($routerDetail);
		}else{
			return false;
		}
	}
}

?>