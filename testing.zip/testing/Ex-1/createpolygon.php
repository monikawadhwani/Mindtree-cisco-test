<?php
// Create a blank image
header('Content-type: image/png');
$image = imagecreatetruecolor(600, 600);
imagesavealpha($png, true);

$trans_colour = imagecolorallocatealpha($image, 255, 255, 255, 127);
imagefill($image, 0, 0, $trans_colour); 

// Allocate a color for the polygon
$col_poly = imagecolorallocatealpha($image, 0, 0, 255,75);

// Draw the polygon
$poly = imagepolygon($image, array(
        200, 100,        
        100, 300,
        200, 500,
        400, 500,
        500, 300,
        400, 100,
    ),
    6,
    $col_poly);
 
/**Create a circle**/
imageellipse($image, 300, 300, 300, 300, $col_poly);

/**Create a inner polygon**/
imagepolygon($image, array(
        300, 200,        
        200, 300,
        300, 400,
        400, 300,
    ),
    4,
 $col_poly);

// Output the picture to the browser
header('Content-type: image/png');

imagepng($image);
imagedestroy($image);
?>