<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Manage Router</title>
	<meta name="description" content="The small framework with powerful features">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
	<style type="text/css">
		
		<style {csp-style-nonce}>
		* {
			transition: background-color 300ms ease, color 300ms ease;
		}
		*:focus {
			background-color: rgba(221, 72, 20, .2);
			outline: none;
		}
		html, body {
			color: rgba(33, 37, 41, 1);
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
			font-size: 16px;
			margin: 0;
			padding: 0;
			-webkit-font-smoothing: antialiased;
			-moz-osx-font-smoothing: grayscale;
			text-rendering: optimizeLegibility;
		}
		header {
			background-color: rgba(247, 248, 249, 1);
			padding: .4rem 0 0;
		}
		.menu {
			padding: .4rem 2rem;
		}
		header ul {
			border-bottom: 1px solid rgba(242, 242, 242, 1);
			list-style-type: none;
			margin: 0;
			overflow: hidden;
			padding: 0;
			text-align: right;
		}
		header li {
			display: inline-block;
		}
		header li a {
			border-radius: 5px;
			color: rgba(0, 0, 0, .5);
			display: block;
			height: 44px;
			text-decoration: none;
		}
		header li.menu-item a {
			border-radius: 5px;
			margin: 5px 0;
			height: 38px;
			line-height: 36px;
			padding: .4rem .65rem;
			text-align: center;
		}
		header li.menu-item a:hover,
		header li.menu-item a:focus {
			background-color: rgba(221, 72, 20, .2);
			color: rgba(221, 72, 20, 1);
		}
		header .heroe {
			margin: 0 auto;
			max-width: 1100px;
			padding: 1rem 1.75rem 1.75rem 1.75rem;
		}
		header .heroe h1 {
			font-size: 2.5rem;
			font-weight: 500;
		}
		header .heroe h2 {
			font-size: 1.5rem;
			font-weight: 300;
		}
		section {
			margin: 0 auto;
			max-width: 1100px;
			padding: 2.5rem 1.75rem 3.5rem 1.75rem;
		}
		section h1 {
			margin-bottom: 2.5rem;
		}
		section h2 {
			font-size: 120%;
			line-height: 2.5rem;
			padding-top: 1.5rem;
		}
		section pre {
			background-color: rgba(247, 248, 249, 1);
			border: 1px solid rgba(242, 242, 242, 1);
			display: block;
			font-size: .9rem;
			margin: 2rem 0;
			padding: 1rem 1.5rem;
			white-space: pre-wrap;
			word-break: break-all;
		}
		section code {
			display: block;
		}
		section a {
			color: rgba(221, 72, 20, 1);
		}
		section svg {
			margin-bottom: -5px;
			margin-right: 5px;
			width: 25px;
		}
		.further {
			background-color: rgba(247, 248, 249, 1);
			border-bottom: 1px solid rgba(242, 242, 242, 1);
			border-top: 1px solid rgba(242, 242, 242, 1);
		}
		.further h2:first-of-type {
			padding-top: 0;
		}
		footer {
			background-color: rgba(221, 72, 20, .8);
			text-align: center;
		}
		footer .environment {
			color: rgba(255, 255, 255, 1);
			padding: 2rem 1.75rem;
		}
		footer .copyrights {
			background-color: rgba(62, 62, 62, 1);
			color: rgba(200, 200, 200, 1);
			padding: .25rem 1.75rem;
		}
		.has-error{color: red;}
		@media (max-width: 559px) {
			header ul {
				padding: 0;
			}
			header .menu-toggle {
				padding: 0 1rem;
			}
			header .menu-item {
				background-color: rgba(244, 245, 246, 1);
				border-top: 1px solid rgba(242, 242, 242, 1);
				margin: 0 15px;
				width: calc(100% - 30px);
			}
			header .menu-toggle {
				display: block;
			}
			header .hidden {
				display: none;
			}
			header li.menu-item a {
				background-color: rgba(221, 72, 20, .1);
			}
			header li.menu-item a:hover,
			header li.menu-item a:focus {
				background-color: rgba(221, 72, 20, .7);
				color: rgba(255, 255, 255, .8);
			}
		}
	</style>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" />
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css"/>

	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<Script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></Script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
	 <script src="<?php echo base_url();?>/assets/js/router.js"></script>
	 <script type="text/javascript">
	  	var url = "<?php echo base_url();?>";
	  </script>
</head>
<body>
	<!-- HEADER: MENU + HEROE SECTION -->
<header>
	<div class="menu">
		<ul>
			<li><a href="<?php echo base_url();?>">Home</a></li>			
		</ul>
	</div>
	<div class="heroe">

		<h1>Manage Router details</h1>

	</div>

</header>

<!-- CONTENT -->
<section>
		<div class="pull-right"><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#addRouter">Add Router Detail</button></div>

		<table id="routerTable" class="table table-striped table-bordered" style="width:100%">
	        <thead>
	            <tr>
	            	<th>Id</th>
	                <th>SAP ID</th>
	                <th>Host Name</th>
	                <th>Loopback</th>
	                <th>MAC Address</th>
	                <th>Action</th>                
	            </tr>
	        </thead>
	        <tbody>
	        	<?php	 
	        	$i =0;      	
	        	foreach ($dns as $dn) {?>
	        		<tr>
	        		<td><?php echo $dn->id;?></td>
	        		<td><?php echo $dn->sapid;?></td>
	        		<td><?php echo $dn->hostname;?></td>
	        		<td><?php echo $dn->loopback;?></td>
	        		<td><?php echo $dn->macadd;?></td>
	        		<td><a href="javascript: void(0)" class="edit-router" data-id="<?= $dn->id;?>">Edit</a> 
	        			<a href="javascript: void(0)" class="delete-router" data-id="<?= $dn->id;?>">Delete</a></td>
	        		</tr>
	        	<?php $i ++; }	        	
	        	?>
	        </tbody>
    	</table>
</section>

<div class="modal" id="addRouter">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Router</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
	       <form class="form-horizontal" method="post" name="addrouterForm" action="<?php echo base_url();?>/addRouter">
			 <div class="form-group">
		    <label class="control-label col-sm-2" for="sapid">Sapid:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" name="sapid" placeholder="Enter Sapid eg: 12:12:34:65-e3:t5:87:54" required>
		    </div>
		  </div>
		   <div class="form-group">
		    <label class="control-label col-sm-3" for="hostname">Host Name:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" name="hostname" placeholder="Enter Host Name eg: 217.198.154.21" required>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="loopback">Loopback:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" name="loopback" placeholder="Enter Loopback eg: 192.168.1.1" required>
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="macadd">Macaddress:</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" name="macadd" placeholder="Enter Macaddress eg: 05:cd:78:a0:b4:c6">
		    </div>
		  </div>
		  <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		    <input type="hidden" name="id" />
		      <button type="submit" class="btn btn-dark">Submit</button>
		    </div>
		  </div>
		</form>
      </div>

      <!-- Modal footer -->
<!--       <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div> -->

    </div>
  </div>
</div>

</body>
</html>