// Wait for the DOM to be ready
$(function() {

  $('#routerTable thead tr').clone(true).appendTo( '#routerTable thead' );
    $('#routerTable thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
   var table = $('#routerTable').DataTable();

  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='addrouterForm']").validate({
  	errorElement: 'span', //default input error message container
            errorClass: 'has-error', // default input error message class
    // Specify validation rules
    rules: {
      sapid: {
        required: true,
        minlength: 18
      },
      hostname:  {
        required: true,
        minlength: 14        
      },
      loopback: {
        required: true,    
        valid_ip: true,    
      },
      macadd: {
        required: true,
        minlength: 17,
        valid_macadd: true,
      }
    },
    // Specify validation error messages
    messages: {
      sapid: {
        required: "Please enter Sapid",
        minlength: "Length should be 18",        
      },
      hostname: {
        required: "Please enter Hostname",
        minlength: "Length should be 14"
      },
      loopback: {
        required: "Please enter Loopback"      
      },
      macadd: {
        required: "Please enter Mac address",
        minlength: "Length should be 17"      
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {  

        $.post( form.action, $("form[name='addrouterForm']").serialize(),function( data ) {    
        	alert("Router Detail added successfully");      
            $("#addRouter").modal('hide');
            window.location.reload();
        });
    }
  });

  jQuery.validator.addMethod("valid_ip", function(value, element){
    if (/^[\d]{0,3}.[\d]{0,3}.[\d]{0,3}.[\d]{0,3}$/.test(value)) {
    	console.log('regex:true');
        return true;  // FAIL validation when REGEX matches
    } else {
    	console.log('regex:false');
        return false;   // PASS validation otherwise
    };
  }, "Enter valid Ipv4"); 

	jQuery.validator.addMethod("valid_macadd", function(value, element){
      if (/^(([A-Fa-f0-9]{2}[:]){5}[A-Fa-f0-9]{2}[,]?)+$/i.test(value)) {
    	console.log('regex:true');
        return true;  // FAIL validation when REGEX matches
    } else {
    	console.log('regex:false');
        return false;   // PASS validation otherwise
    };
  }, "Enter valid MAC Address"); 



  $(".edit-router").click(function(){
     let id = $(this).attr("data-id");
      $.get(url+"/getRouter/"+id, function(data, status){        
        let router =JSON.parse(data);              
        $("input[name=sapid]").val(router[0].sapid);
        $("input[name=hostname]").val(router[0].hostname);
        $("input[name=loopback]").val(router[0].loopback);
        $("input[name=macadd]").val(router[0].macadd);
        $("input[name=id]").val(router[0].id);
        $("#addRouter").modal('show');
        $('#addRouter .modal-title').html('Edit Router');
        $('#addRouter form').attr('action',url+'/editRouter');
      });
  });

  $(".delete-router").click(function(){
     let id = $(this).attr("data-id");
      let conf = confirm("Are you sure you want to delete this entry?");
      if(conf){
        $.get(url+"/deleteRouter/"+id, function(data, status){        
          
          alert("Data:"+data+" Status:"+status);           
          
        });
      }
  });

});